/** @type {import('tailwindcss').Config} */
export default {
    content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
    theme: {
        extend: {
            colors: {
                primary: {
                    light: "#00BFFF", // Lighter teal shade
                    default: "#008080", // Teal color as an example
                    dark: "#004080", // Darker teal shade
                },
                secondary: {
                    light: "#FFC0CB", // Light Pink
                    default: "#FF69B4", // Medium Pink
                    dark: "#D6007E",  // Dark Pink
                },
                // Add more natural colors as needed
            },
        },
    },
    plugins: [],
};

