//userContext.jsx

import React, {createContext, useContext} from "react";
import {getUserDataByEmail} from "../lib/GettingUserInfo";
import {getAllDataFromObjectStore} from "../lib/gettingGroupList"
import { getGroupDataById } from "../lib/getGroupData";
import { getGroupListById } from "../lib/groupListByID";
import { searching } from "../lib/searchGroup";

const LocalUserContext = createContext({});

const LocalStateContext = LocalUserContext.Provider;

const UserContextProvider = ({children}) => {
    const logout = () => {
        localStorage.removeItem("@logeIn");
        localStorage.removeItem("email");

        localStorage.removeItem("groupId");

        window.location.reload();
    };

    const UserLogin = (userCredential) => {
        getUserDataByEmail(userCredential.email)
            .then((userData) => {
                if (!userData) {
                    alert("User not register!");
                    return;
                }

                if (userData && userData.password === userCredential.password) {
                    localStorage.setItem("@logeIn", true);
                    localStorage.setItem("email", userCredential.email);

                    window.location.href = "/";
                } else {
                    alert("Something wrong!, Check Email & Password");
                }
            })
            .catch((error) => {
                alert("Something wrong!" + error);
            });
    };

    const createTeam = (teamName) => {
        return new Promise((resolve, reject) => {
          // Use getAllDataFromObjectStore to get the list of existing groups
          getAllDataFromObjectStore((data) => {
            const isUnique = data.every((group) => group.name !== teamName);
    
            if (isUnique) {
              // Team name is unique, resolve the promise
              resolve(true);
            } else {
              // Team name already exists, reject the promise
              alert("Team with this title already exists!! Please select a unique name");
              reject(false);
            }
          });
        });
      };

    function addUserToTeam(email) {
        return new Promise((resolve, reject) => {
            getUserDataByEmail(email)
                .then((userData) => {
                    // Check if email exists in local storage
                    if (userData) {
                        // Email already exists
                        // Add code to add user to team if necessary
    
                        resolve(true); // Resolve the promise with a truthy value
                    } else {
                        // Email not found, show alert
                        alert('User not found!! Please check the email.');
                        reject(false); // Reject the promise with a falsy value
                    }
                })
                .catch((error) => {
                    // Handle any errors that occur during the asynchronous operation
                    console.error('Error adding user to team:', error);
                    reject(false); // Reject the promise with a falsy value
                });
        });
    };

    function deleteUserFromTeam(email, group_Id) {
      return new Promise((resolve, reject) => {
        getUserDataByEmail(email)
          .then((userData) => {
            // Check if email exists in local storage
            if (userData) {
              getGroupDataById(group_Id, (groupData) => {
                if (groupData && groupData.teamList.includes(email)) {
                  // User is in the team, resolve the promise
                  resolve(true);
                } else {
                  // User is not in the team, reject the promise
                  alert("User is not in the team!!");
                  reject(false);
                }
              });
            } else {
              // Email not found, show alert
              alert("User not found!! Please check the email.");
              reject(false); // Reject the promise with a falsy value
            }
          })
          .catch((error) => {
            // Handle any errors that occur during the asynchronous operation
            console.error("Error checking user in team:", error);
            reject(false); // Reject the promise with a falsy value
          });
  }); }

  function checkUserInTeam(email, group_Id) {
    return new Promise((resolve, reject) => {
      getUserDataByEmail(email)
        .then((userData) => {
          console.log("User Data:", userData);
  
          if (userData) {
            console.log("Group ID:", group_Id); // Log the group ID
            return getGroupListById(group_Id);
          } else {
            // Email not found, reject the promise
            alert("User not found!! Please check the email.");
            reject(false);
          }
        })
        .then((groupData) => {
          console.log("Group Data:", groupData);
  
          const lowercaseEmail = email.toLowerCase();
          if (groupData && groupData.teamList.includes(lowercaseEmail)) {
            // User is in the team, resolve the promise
            resolve(true);
          } else {
            // User is not in the team, reject the promise
            alert("User is not in the team!!");
            reject(false);
          }
        })
        .catch((error) => {
          // Handle any errors that occur during the asynchronous operation
          console.error("Error checking user in team:", error);
          reject(false); // Reject the promise with a falsy value
        });
    });
  }
  
  
    return (
        <React.Fragment>
            <LocalStateContext value={{logout, UserLogin, createTeam, addUserToTeam, deleteUserFromTeam,checkUserInTeam}}>
                {children}
            </LocalStateContext>
        </React.Fragment>
    );
};

const useUser = () => useContext(LocalUserContext);

export {UserContextProvider, useUser};