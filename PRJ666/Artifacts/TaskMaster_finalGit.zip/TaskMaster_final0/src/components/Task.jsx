//Task.jsx

import {CalendarRange} from "lucide-react";
import React from "react";

export default function Task({taskCard}) {
    const {description, title, due_date, priority, status, assign_to, file} =
        taskCard;

    return (
        <>
            <div className="text-white border-l border-dotted bg-Dark p-4 rounded" style={{ backgroundColor: "#39393f" }}>
                 <div className="flex justify-between">
                    <h3 className="text-lg font-semibold"> {title} </h3>
                </div>
                <p className="text-sm ">{description}</p>

                <p className="text-sm mt-2 text-pink-500">
                    Assign to:
                    <span className="text-pink-300 ml-2">{assign_to}</span>
                </p>

                <div className="flex justify-between mt-4 mb-2">
                    <div className="flex items-center text-xs">
                        <CalendarRange size={12} />
                        <p className="ml-1">{due_date}</p>
                    </div>

                    <div className="flex justify-start items-center space-x-2">
                    <p
                        className={`text-xs px-2 py-1 rounded-full ${
                            (status === "new task" && "bg-purple-500/30 text-white") ||
                            (status === "processing" && "bg-yellow-500/30 text-white") ||
                            (status === "completed" && "bg-green-500/30 text-white")
                        }`}
                    >
                        {status}
                    </p>

                    <p
                        className={`text-xs px-2 py-1 rounded-full ${
                            (priority === "normal" && "bg-gray-500/30 text-white") ||
                            (priority === "medium" && "bg-blue-500/30 text-white") ||
                            (priority === "urgent" && "bg-red-600 text-white")
                        }`}
                    >
                        {priority}
                    </p>
                    </div>
                </div>
                
                {file && (
                    <div className="mt-2">
                        <p className="text-xs font-semibold">Attached File:</p>
                        <a
                            href={URL.createObjectURL(file)}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue-500 underline"
                        >
                            {file.name}
                        </a>
                    </div>
                )}
            </div>
        </>
    );
}
