//createTask.jsx

import {CheckCheck, XSquare} from "lucide-react";
import React, {useState} from "react";
import ReactDatePicker from "react-datepicker";
import {createTask} from "../lib/createTask";
import {formatDate} from "../lib/dateFormt";
import ModalState from "./Modal";
import { useUser } from "../context/userContext";

export default function CreateTask({isOpen, setIsOpen, group_Id}) {
    const [startDate, setStartDate] = useState(new Date());
    const {addUserToTeam, checkUserInTeam, deleteUserFromTeam} = useUser();

    const [taskValue, setTaskValue] = useState({
        title: "",
        assign_to: "",
        description: "",
        status: "new task",
        due_date: formatDate(startDate),
        priority: "normal",
        file: "",
    });

    const [notification, setNotification] = useState(null);

    const handleInputChange = (e) => {
        const {name, value} = e.target;
        setTaskValue({
            ...taskValue,
            [name]: value,
        });
    };

    const showNotification = (message) => {
        setNotification(message);
    
        // Clear notification after 3 seconds
        setTimeout(() => {
          setNotification(null);
        }, 3000);
        
      };

    const handleTaskCreate = async(e) => {
        e.preventDefault();

        try {
            // Check if the assigned user is in the team
            await addUserToTeam(taskValue.assign_to);
            //await deleteUserFromTeam(taskValue.assign_to, group_Id);
            //await checkUserInTeam(taskValue.assign_to, group_Id);
      
            // If the user is in the team, proceed with creating the task
            createTask({
              group_Id: localStorage.getItem("groupId"),
              ...taskValue,
              due_date: formatDate(startDate),
            });

            // Show in-app notification
            showNotification(`Task "${taskValue.title}" created successfully!, assigned to "${taskValue.assign_to}"`);
      
            setIsOpen(false);
      
            setStartDate(new Date());
      
            setTaskValue({
              title: "",
              description: "",
              status: "new task",
              due_date: formatDate(new Date()),
              priority: "normal",
              file: ""
            });
          } catch (error) {
            // Handle the error (user not in the team)
            console.error("Task creation error:", error);
            // You can display an error message to the user on the UI or handle it accordingly
          }
    };

    return (
        <>
            <button
                onClick={() => setIsOpen(true)}
                className="bg-pink-600 hover:bg-pink-500 transition-all ease-linear p-2 rounded text-white font-medium"
            >
                <CheckCheck className="inline mr-1" />
                Create Task
            </button>

            <div className="h-[1px] w-full bg-pink-600 mt-6"></div>

            <ModalState isOpen={isOpen}>
                <div className="bg-white w-full lg:min-w-[500px] p-5 rounded">
                    <button
                        onClick={() => setIsOpen(false)}
                        className="text-pink-600 float-right hover:text-pink-400 transition-all ease-linear"
                    >
                        <XSquare size={18} />
                    </button>
                    <h4 className="text-base font-medium">- Create Task</h4>
                    <form onSubmit={handleTaskCreate} className="text-sm">
                        <div>
                            <label
                                className="block text-sm mb-1 mt-4"
                                htmlFor="name"
                            >
                                Title
                            </label>
                            <input
                                name="title"
                                id="name"
                                value={taskValue.title}
                                onChange={handleInputChange}
                                className="border py-2 px-2 rounded w-full"
                                type="text"
                                placeholder=" Title name"
                                required
                            />
                        </div>

                        <div>
                            <label
                                className="block text-sm mb-1 mt-4"
                                htmlFor="description"
                            >
                                Description
                            </label>
                            <textarea
                                name="description"
                                id="description"
                                value={taskValue.description}
                                onChange={handleInputChange}
                                cols="30"
                                rows="2"
                                className="border py-2 px-2 rounded w-full"
                                placeholder="Description"
                                required
                            ></textarea>
                        </div>

                        <div>
                            <label
                                className="block text-sm mb-1 mt-4"
                                htmlFor="name"
                            >
                                Task assign to
                            </label>
                            <input
                                name="assign_to"
                                id="assign_to"
                                value={taskValue.assign_to}
                                onChange={handleInputChange}
                                className="border py-2 px-2 rounded w-full"
                                type="text"
                                placeholder="Enter team members email"
                                required
                            />
                        </div>

                        <div className="flex items-center gap-4">
                            <div className="w-full">
                                <label
                                    className="block text-sm mb-1 mt-4"
                                    htmlFor="description"
                                >
                                    Status
                                </label>
                                <select
                                    className="border py-2 px-2 rounded w-full bg-transparent"
                                    name="status"
                                    value={taskValue.status}
                                    onChange={handleInputChange}
                                    id="priority"
                                    required
                                >
                                    <option value="new">New Task</option>

                                    <option value="processing">
                                        Processing
                                    </option>

                                    <option value="completed">Completed</option>
                                </select>
                            </div>

                            <div className="w-full">
                                <label
                                    className="block text-sm mb-1 mt-4"
                                    htmlFor="description"
                                >
                                    Due Date
                                </label>
                                <ReactDatePicker
                                    selected={startDate}
                                    className="border py-2 px-2 rounded w-full"
                                    onChange={(date) => setStartDate(date)}
                                />
                            </div>
                        </div>

                        <div className="w-full">
                            <label
                                className="block text-sm mb-1 mt-4"
                                htmlFor="description"
                            >
                                Priority
                            </label>
                            <select
                                className="border py-2 px-2 rounded w-full bg-transparent"
                                name="priority"
                                value={taskValue.priority}
                                onChange={handleInputChange}
                                id="priority"
                            >
                                <option value="normal">Normal</option>

                                <option value="medium">Medium</option>

                                <option value="urgent">Urgent</option>
                            </select>
                        </div>

                        <button
                            className="w-full bg-pink-500 hover:bg-pink-500/80 mt-4 py-2 rounded text-white transition-all ease-linear font-medium"
                            type="submit"
                        >
                            Create Task
                        </button>
                    </form>
                </div>
            </ModalState>
            {notification && (
            <div className="notification">
            {notification}
            </div>
        )}
        </>
    );
}
