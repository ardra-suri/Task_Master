import React, { useState } from "react";
import { XSquare } from "lucide-react";
import { onAddMember, onDeleteMember } from "../lib/editMemberToGroup";
import { getUserDataByEmail } from "../lib/GettingUserInfo";
import { useUser } from "../context/userContext";

export default function AddMemberModal({ groupId, isOpen, onClose }) {
  const [newMemberEmail, setNewMemberEmail] = useState("");
  const [isEmailValid, setIsEmailValid] = useState(true);

  const { addUserToTeam,  deleteUserFromTeam} = useUser();

  const handleAddMemberSubmit = async () => {
    try {
      const result = await addUserToTeam(newMemberEmail);
      if (result) {
        await onAddMember(groupId, newMemberEmail);
      }
      // Close the modal
      onClose();
      // Clear the input and validation state
      setNewMemberEmail("");
    } catch (error) {
      console.error("Error adding member:", error);
      // Handle error, display a message, or log it as needed
    }
  };

  const handleDeleteMember = async () => {
    try {
      const result = await deleteUserFromTeam(newMemberEmail, groupId)
      if(result){
        // Assuming onDeleteMember is a function that deletes a member
        await onDeleteMember(groupId, newMemberEmail);
      }
      // Close the modal
      onClose();
      // Clear the input and validation state
      setNewMemberEmail("");
    } catch (error) {
      console.error("Error deleting member:", error);
      // Handle error, display a message, or log it as needed
    }
  };

  const handleCancel = () => {
    // Clear the input and validation state
    setNewMemberEmail("");
    // Close the modal
    onClose();
  };

  return (
    <>
      {isOpen && (
        <div className="fixed top-0 left-0 w-full h-full bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-4 rounded">
            <button
              onClick={onClose}
              className="text-pink-600 float-right hover:text-pink-400 transition-all ease-linear"
            >
              <XSquare size={18} />
            </button>
            <label htmlFor="newMemberEmail" className="block text-sm mb-1">
              Enter Member's Email:
            </label>
            <input
              type="email"
              id="newMemberEmail"
              className={`border py-2 px-2 rounded w-full ${
                isEmailValid ? "text-black" : "border-red-500"
              }`}
              placeholder="Email"
              value={newMemberEmail}
              onChange={(e) => setNewMemberEmail(e.target.value)}
              required
            />
            <div className="flex justify-end mt-4">
              <button
                onClick={handleAddMemberSubmit}
                className="bg-pink-500 py-2 px-4 rounded text-white mr-2"
              >
                Add
              </button>
              <button
                onClick={handleDeleteMember}
                className="bg-red-500 py-2 px-4 rounded text-white mr-2"
              >
                Delete
              </button>
              <button
                onClick={handleCancel}
                className="bg-gray-500 py-2 px-4 rounded text-white"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
















// // AddMemberModal.jsx

// import React, { useState } from "react";
// import { XSquare } from "lucide-react";
// import { onAddMember } from "../lib/editMemberToGroup";
// import { getUserDataByEmail } from "../lib/GettingUserInfo";
// import {useUser} from "../context/userContext";

// export default function AddMemberModal({ groupId, isOpen, onClose }) {
//   const [newMemberEmail, setNewMemberEmail] = useState("");
//   const [isEmailValid, setIsEmailValid] = useState(true);

//   const {addUserToTeam} = useUser();
  
//   const handleAddMemberSubmit = async () => {

//     try {
//       const result = await addUserToTeam(newMemberEmail);
//       if (result){
//         await onAddMember(groupId, newMemberEmail);
//       }
//       // Close the modal
//       onClose();
//       // Clear the input and validation state
//       setNewMemberEmail("");
//     } catch (error) {
//       console.error("Error adding member:", error);
//       // Handle error, display a message, or log it as needed
//     }
     
//   };

//   const handleCancel = () => {
//     // Clear the input and validation state
//     setNewMemberEmail("");
//     // Close the modal
//     onClose();
//   };

//   return (
//     <>
//       {isOpen && (
//         <div className="fixed top-0 left-0 w-full h-full bg-black bg-opacity-50 flex items-center justify-center">
//           <div className="bg-white p-4 rounded">
//             <button
//               onClick={onClose}
//               className="text-pink-600 float-right hover:text-pink-400 transition-all ease-linear"
//             >
//               <XSquare size={18} />
//             </button>
//             <label htmlFor="newMemberEmail" className="block text-sm mb-1">
//               Enter Member's Email:
//             </label>
//             <input
//               type="email"
//               id="newMemberEmail"
//               className={`border py-2 px-2 rounded w-full ${
//                 isEmailValid ? "text-black" : "border-red-500"
//               }`}
//               placeholder="Email"
//               value={newMemberEmail}
//               onChange={(e) => setNewMemberEmail(e.target.value)}
//               required
//             />
//             <div className="flex justify-end mt-4">
//               <button
//                 onClick={handleAddMemberSubmit}
//                 className="bg-pink-500 py-2 px-4 rounded text-white mr-2"
//               >
//                 Add
//               </button>
//               <button
//                 onClick={handleCancel}
//                 className="bg-gray-500 py-2 px-4 rounded text-white"
//               >
//                 Cancel
//               </button>
//             </div>
//           </div>
//         </div>
//       )}
//     </>
//   );
// }
