import React from "react";

export default function Logo() {
    return (
        <div className="flex justify-center items-center flex-col">
            <div className="flex">
                <span className="text-4xl text-light ml-2 font-extrabold">
                    TaskMaster
                </span>
            </div>
        </div>
    );
}