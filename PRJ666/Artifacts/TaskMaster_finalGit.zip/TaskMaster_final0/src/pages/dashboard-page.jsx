// import React, {useState} from "react";
// import {getAllTasks} from "../lib/getTasks";

// export default function DashboardPage() {
//     const [allTask, setAllTask] = useState([]);

//     getAllTasks((data) => {
//         setAllTask(data);
//     });

//     const date = new Date().toDateString();
//     return (
//         <>

//             <div className=" text-white mx-2 mb-6 p-4 rounded ">
//                 <h1 className="text-5xl font-bold">
//                     Welcome to Our TaskMaster!
//                 </h1>
//             </div>
//         </>
//     );
// }

import React, { useState, useEffect } from "react";
import { getAllTasks } from "../lib/getTasks";
import { format, isToday } from "date-fns";

const DashboardPage = () => {
  const [assignedTasks, setAssignedTasks] = useState([]);
  const userEmail = localStorage.getItem("email");

  useEffect(() => {
    // Fetch all tasks when the component mounts
    getAllTasks((data) => {
      try {
        // Filter tasks assigned to the current user
        const tasksAssignedToUser = data.filter(
          (task) => task.assign_to === userEmail
        );
        setAssignedTasks(tasksAssignedToUser);
      } catch (error) {
        console.error("Error fetching or processing tasks:", error);
        // Handle the error, e.g., display an error message to the user
      }
    });
  }, [userEmail]);

  const date = new Date().toDateString();

  // Filter tasks with today's due date
  const todayTasks = assignedTasks.filter((task) => {
    const taskDueDate = new Date(task.due_date);
    return isToday(taskDueDate);
  });

  return (
    <div className="bg-gray-900 min-h-screen text-white p-6" style={{ backgroundColor: "#3f657f" }}>
      <h1 className="text-5xl font-bold mb-8 ">Welcome to Our TaskMaster!</h1>

      <div className="bg-gray-800 p-8 rounded-lg shadow-xl mb-8" style={{ backgroundColor: "#52748b" }}>
        <p className="text-lg mb-4 ">Total assigned tasks: {assignedTasks.length}</p>
        <p className="text-lg mb-6 ">Current date: {date}</p>

        <div>
          <h2 className="text-2xl font-semibold mb-4 ">Today's Assigned Tasks:</h2>
          {todayTasks.length > 0 ? (
            todayTasks.map((task) => (
              <div key={task.id} className="bg-gray-700 p-6 rounded-md mb-4" style={{ backgroundColor: "#39393f" }}>
                <h3 className="text-lg font-semibold text-pink-500">{task.title}</h3>
                <p className="text-sm text-gray-400">
                  Due: {format(new Date(task.due_date), "hh:mm aa")}
                </p>
                <p className="mt-2 text-pink-500">{task.description}</p>
              </div>
            ))
          ) : (
            <p className="text-pink-500">No assigned tasks for today.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;

